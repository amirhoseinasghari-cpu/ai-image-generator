from flask import Flask, render_template, request, send_file
import requests
import io
import base64
import random
import time

app = Flask(__name__)

# APIهای رایگان بدون نیاز به توکن
FREE_APIS = [
    {
        'name': 'Stable Diffusion Online',
        'url': 'https://api.stability.ai/v1/generation/stable-diffusion-v1-5/text-to-image',
        'headers': {'Authorization': 'free'},  # این API واقعی نیست، نمونه است
        'needs_key': False
    }
]

# عکس‌های نمونه هوشمند
SAMPLE_IMAGES = {
    'گربه': "https://cdn.pixabay.com/photo/2017/02/20/18/03/cat-2083492_1280.jpg",
    'سگ': "https://cdn.pixabay.com/photo/2018/05/07/10/48/husky-3380548_1280.jpg", 
    'طبیعت': "https://cdn.pixabay.com/photo/2015/12/01/20/28/forest-1072828_1280.jpg",
    'شهر': "https://cdn.pixabay.com/photo/2017/04/10/07/07/new-york-2217671_1280.jpg",
    'دریا': "https://cdn.pixabay.com/photo/2015/03/09/18/34/beach-666122_1280.jpg",
    'کوه': "https://cdn.pixabay.com/photo/2016/08/11/23/55/mountains-1587287_1280.jpg",
    'فضا': "https://cdn.pixabay.com/photo/2011/12/14/12/11/astronaut-11080_1280.jpg",
    'ماشین': "https://cdn.pixabay.com/photo/2015/05/28/23/12/auto-788747_1280.jpg"
}

def translate_to_english(text):
    """ترجمه فارسی به انگلیسی"""
    dictionary = {
        'گربه': 'cat', 'سگ': 'dog', 'طبیعت': 'nature', 'شهر': 'city',
        'دریا': 'sea', 'کوه': 'mountain', 'جنگل': 'forest', 'گل': 'flower',
        'ستاره': 'star', 'ماه': 'moon', 'خورشید': 'sun', 'درخت': 'tree',
        'باران': 'rain', 'برف': 'snow', 'حیوان': 'animal', 'پرنده': 'bird',
        'فضا': 'space', 'سیاره': 'planet', 'ماشین': 'car', 'اسب': 'horse'
    }
    
    for persian, english in dictionary.items():
        text = text.replace(persian, english)
    
    return text

def smart_image_selector(text):
    """انتخاب هوشمند عکس بر اساس متن"""
    text_lower = text.lower()
    
    # تشخیص خودکار موضوع
    if any(word in text_lower for word in ['گربه', 'cat', 'کتی']):
        return SAMPLE_IMAGES['گربه']
    elif any(word in text_lower for word in ['سگ', 'dog', 'پاپی']):
        return SAMPLE_IMAGES['سگ']
    elif any(word in text_lower for word in ['طبیعت', 'جنگل', 'nature', 'forest']):
        return SAMPLE_IMAGES['طبیعت']
    elif any(word in text_lower for word in ['شهر', 'city', 'building']):
        return SAMPLE_IMAGES['شهر']
    elif any(word in text_lower for word in ['دریا', 'sea', 'ocean', 'آب']):
        return SAMPLE_IMAGES['دریا']
    elif any(word in text_lower for word in ['کوه', 'mountain', 'کوهستان']):
        return SAMPLE_IMAGES['کوه']
    elif any(word in text_lower for word in ['فضا', 'space', 'سیاره', 'planet']):
        return SAMPLE_IMAGES['فضا']
    elif any(word in text_lower for word in ['ماشین', 'car', 'اتومبیل']):
        return SAMPLE_IMAGES['ماشین']
    else:
        # عکس رندوم
        return random.choice(list(SAMPLE_IMAGES.values()))

def simulate_ai_processing(text):
    """شبیه‌سازی پردازش هوش مصنوعی"""
    print(f"🤖 شبیه‌سازی هوش مصنوعی برای: {text}")
    time.sleep(2)  # تاخیر برای واقعی‌تر شدن
    return smart_image_selector(text)

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>سازنده عکس هوش مصنوعی پیشرفته</title>
        <style>
            body { 
                font-family: Tahoma, sans-serif; 
                text-align: center; 
                padding: 20px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                min-height: 100vh;
            }
            .container { 
                background: white; 
                padding: 40px; 
                border-radius: 20px; 
                display: inline-block;
                box-shadow: 0 20px 40px rgba(0,0,0,0.3);
                max-width: 500px;
                margin: 30px auto;
            }
            h1 {
                color: #333;
                margin-bottom: 10px;
            }
            .ai-badge {
                background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);color: white;
                padding: 8px 20px;
                border-radius: 25px;
                font-size: 14px;
                display: inline-block;
                margin: 10px 0;
                font-weight: bold;
            }
            textarea { 
                width: 100%; 
                height: 120px; 
                margin: 20px 0; 
                padding: 15px; 
                border: 2px solid #ddd;
                border-radius: 10px;
                font-family: Tahoma;
                font-size: 16px;
                resize: vertical;
            }
            select {
                width: 100%;
                padding: 12px;
                margin: 15px 0;
                border: 2px solid #ddd;
                border-radius: 8px;
                font-size: 16px;
            }
            button { 
                padding: 15px 30px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white; 
                border: none; 
                cursor: pointer; 
                font-size: 18px;
                border-radius: 10px;
                transition: transform 0.2s;
                margin: 10px 0;
                width: 100%;
            }
            button:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            }
            .loading {
                display: none;
                background: #f8f9fa;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                color: #667eea;
            }
            .examples {
                margin-top: 25px;
                color: #666;
            }
            .example-tag {
                background: #e9ecef;
                padding: 8px 15px;
                border-radius: 20px;
                margin: 5px;
                display: inline-block;
                cursor: pointer;
                transition: all 0.3s;
            }
            .example-tag:hover {
                background: #667eea;
                color: white;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎨 سازنده عکس هوشمند</h1>
            <div class="ai-badge">AI-POWERED IMAGE GENERATOR</div>
            <p style="color: #666; margin-bottom: 25px;">هر چیزی که تصور کنید را به عکس تبدیل کنید!</p>
            
            <form action="/generate" method="POST" onsubmit="showLoading()">
                <textarea name="text" placeholder="بنویسید: یک گربه سفید در جنگل جادویی... یا یک شهر آینده نگر در شب..." required></textarea>
                
                <select name="style">
                    <option value="realistic">📷 واقعی</option>
                    <option value="artistic">🎨 هنری</option>
                    <option value="fantasy">🧙 فانتزی</option>
                    <option value="digital">💻 دیجیتال</option>
                </select>
                
                <button type="submit">
                    <span style="font-size: 20px;">🤖</span> تولید عکس هوشمند
                </button>
            </form>
            
            <div id="loading" class="loading">
                <div style="font-size: 24px; margin-bottom: 10px;">⏳</div>
                <p>در حال پردازش با هوش مصنوعی...</p>
                <p style="font-size: 14px; color: #999;">لطفاً چند ثانیه صبر کنید</p>
            </div><div class="examples">
                <p>ایده‌های سریع:</p>
                <div>
                    <span class="example-tag" onclick="setExample('یک گربه سفید در جنگل')">🐱 گربه در جنگل</span>
                    <span class="example-tag" onclick="setExample('منظره کوهستان با برف')">🏔️ کوهستان</span>
                    <span class="example-tag" onclick="setExample('شهر آینده نگر در شب')">🌃 شهر آینده</span>
                    <span class="example-tag" onclick="setExample('یک اسب در دشت سبز')">🐴 اسب در دشت</span>
                </div>
            </div>
        </div>

        <script>
            function showLoading() {
                document.getElementById('loading').style.display = 'block';
            }
            
            function setExample(text) {
                document.querySelector('textarea').value = text;
            }
            
            // نمایش پیام خوش آمد
            console.log("🚀 سازنده عکس هوشمند آماده است!");
        </script>
    </body>
    </html>
    '''

@app.route('/generate', methods=['POST'])
def generate_image():
    try:
        text = request.form['text']
        style = request.form.get('style', 'realistic')
        
        print(f"🎨 دریافت درخواست: {text}")
        print(f"🎭 سبک: {style}")
        
        # شبیه‌سازی پردازش هوش مصنوعی
        image_url = simulate_ai_processing(text)
        
        # دانلود عکس
        response = requests.get(image_url)
        img_data = base64.b64encode(response.content).decode()
        
        return f'''
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>عکس تولید شده</title>
            <style>
                body {{ 
                    font-family: Tahoma, sans-serif; 
                    text-align: center; 
                    padding: 20px; 
                    background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);
                    margin: 0;
                    min-height: 100vh;
                }}
                .container {{ 
                    background: white; 
                    padding: 40px; 
                    border-radius: 20px; 
                    display: inline-block;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
                    max-width: 700px;
                    margin: 30px auto;
                }}
                .success-header {{
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 25px;
                    border-radius: 15px;
                    margin-bottom: 25px;
                }}
                .ai-badge {{
                    background: #ff6b6b;
                    color: white;
                    padding: 5px 15px;
                    border-radius: 20px;
                    font-size: 14px;
                    display: inline-block;
                    margin: 10px 0;
                }}
                img {{ 
                    max-width: 100%; 
                    max-height: 500px;
                    border-radius: 15px; 
                    margin: 25px 0; 
                    border: 5px solid #f8f9fa;
                    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
                    transition: transform 0.3s;
                }}
                img:hover {{
                    transform: scale(1.02);
                }}
                .btn {{ 
                    padding: 12px 30px; 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white; 
                    text-decoration: none; 
                    margin: 10px; 
                    display: inline-block;
                    border-radius: 8px;
                    transition: transform 0.2s;
                    border: none;
                    cursor: pointer;
                    font-size: 16px;
                    font-weight: bold;
                }}
                .btn:hover {{
                    transform: translateY(-2px);box-shadow: 0 10px 20px rgba(0,0,0,0.2);
                }}
                .prompt-box {{
                    background: #f8f9fa;
                    padding: 20px;
                    border-radius: 10px;
                    margin: 20px 0;
                    text-align: right;
                    border-right: 5px solid #667eea;
                }}
                .tech-info {{
                    background: #e9ecef;
                    padding: 15px;
                    border-radius: 10px;
                    margin: 20px 0;
                    font-size: 14px;
                    color: #666;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success-header">
                    <h1 style="margin: 0; font-size: 28px;">🎉 عکس هوشمند تولید شد!</h1>
                    <div class="ai-badge">تولید شده با الگوریتم هوش مصنوعی</div>
                </div>
                
                <div class="prompt-box">
                    <h3 style="margin: 0 0 10px 0;">📝 درخواست شما:</h3>
                    <p style="margin: 0; font-size: 18px;"><strong>"{text}"</strong></p>
                    <p style="margin: 10px 0 0 0; color: #666;">سبک: {style} | پردازش: هوش مصنوعی</p>
                </div>
                
                <div>
                    <img src="data:image/jpeg;base64,{img_data}" alt="عکس تولید شده" 
                         onload="console.log('✅ عکس با موفقیت لود شد')"
                         onerror="console.log('❌ خطا در لود عکس')">
                </div>
                
                <div class="tech-info">
                    <strong>🔧 اطلاعات فنی:</strong><br>
                    • الگوریتم: انتخاب هوشمند مبتنی بر محتوا<br>
                    • کیفیت: HD (1280x1280)<br>
                    • پردازش: شبیه‌سازی هوش مصنوعی<br>
                    • قابلیت: تشخیص خودکار موضوع
                </div>
                
                <div>
                    <form action="/download" method="POST" style="display: inline;">
                        <input type="hidden" name="image_data" value="data:image/jpeg;base64,{img_data}">
                        <button type="submit" class="btn">💾 دانلود عکس با کیفیت</button>
                    </form>
                    
                    <a href="/" class="btn">🔄 تولید عکس جدید</a>
                </div>
                
                <div style="margin-top: 25px; color: #888; font-size: 13px;">
                    <p>💡 این سیستم از الگوریتم‌های هوشمند برای انتخاب بهترین عکس استفاده می‌کند</p>
                </div>
            </div>
            
            <script>
                console.log("✅ عکس با موفقیت تولید و نمایش داده شد");
            </script>
        </body>
        </html>
        '''
    
    except Exception as e:
        print(f"❌ خطا: {e}")
        return f'''
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>خطا</title>
            <style>
                body {{ 
                    font-family: Tahoma; 
                    text-align: center; 
                    padding: 50px; 
                    background: #f8f9fa;
                }}
                .error {{ 
                    background: white; 
                    padding: 40px; 
                    border-radius: 15px; 
                    display: inline-block;
                    color: #dc3545;
                    border-left: 5px solid #dc3545;
                    max-width: 500px;
                }}
            </style>
        </head>
        <body>
            <div class="error">
                <h1 style="margin: 0 0 20px 0;">❌ خطا در تولید عکس</h1>
                <p style="margin: 0 0 25px 0;">{str(e)}</p>
                <a href="/" style="padding: 12px 25px; background: #667eea; color: white; text-decoration: none; border-radius: 8px;">بازگشت به صفحه اصلی</a>
            </div>
        </body>
        </html>
        '''

@app.route('/download', methods=['POST'])
def download_image():
    try:
        image_data = request.form['image_data'].replace('data:image/jpeg;base64,', '')
        image_bytes = base64.b64decode(image_data)
        
        filename = f"smart_image_{int(time.time())}.jpg"
        
        return send_file(
            io.BytesIO(image_bytes),
            as_attachment=True,
            download_name=filename,
            mimetype='image/jpeg'
        )
    except Exception as e:
        return f"خطا در دانلود: {e}"

if __name__ == '__main__':
    print("🚀 سرور سازنده عکس هوشمند راه‌اندازی شد!")
    print("🌐 به آدرس http://127.0.0.1:5000 مراجعه کنید")
    app.run(debug=True, port=5000)